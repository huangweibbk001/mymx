import setuptools
setuptools.setup(name='mymx',
      version='0.0.2',
      description='just test python pip module',
      url='https://github.com/huangweibbk001/mymx',
      author='__token__',
      author_email='pypi-AgEIcHlwaS5vcmcCJDNmNTgzNjcxLTY0ZjctNDZmMS1hMWQwLWU1ZmIzODYyNTVmZAACKlszLCIwYjI2MTgwMC05NGI0LTRhZTUtOGM0Yy0wMmI0OWZlOWE2OTUiXQAABiApfewp3c1tzyu1I5zPCyD49968wJsOujSXB4rK2YfxHQ',
      license='MIT',
      packages=setuptools.find_packages(),
      zip_safe=False)