import setuptools
setuptools.setup(name='mymx',
      version='0.0.2',
      description='just test python pip module',
      url='https://github.com/huangweibbk001/mymx',
      author='huangweigang',
      author_email='huangweibbk001@googlemail.com',
      license='MIT',
      packages=setuptools.find_packages(),
      zip_safe=False)