def dd():
    return 'my'